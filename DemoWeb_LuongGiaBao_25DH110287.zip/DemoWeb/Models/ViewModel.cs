using System;
using System.Collections.Generic;

namespace DemoWeb.Models
{
    public class ViewModel
    {
        public int? IDPro { get; set; }
        public string NamePro { get; set; }
        public string ImgPro { get; set; }
        public decimal pricePro { get; set; }
        public int? Sum_Quantity { get; set; }
    }
}
