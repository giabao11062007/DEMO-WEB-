using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DemoWeb.Models
{
    public class OrderDetail
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ID { get; set; }

        [Display(Name = "Mã sản phẩm")]
        public int? IDProduct { get; set; }

        [Display(Name = "Mã hóa đơn")]
        public int? IDOrder { get; set; }

        [Display(Name = "Số lượng")]
        public int? Quantity { get; set; }

        [Display(Name = "Đơn giá")]
        [Column(TypeName = "decimal(18,2)")]
        public decimal? UnitPrice { get; set; }

        [ForeignKey("IDProduct")]
        public virtual Product Product { get; set; }

        [ForeignKey("IDOrder")]
        public virtual OrderPro OrderPro { get; set; }
    }
}
