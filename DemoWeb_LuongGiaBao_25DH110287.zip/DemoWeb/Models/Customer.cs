using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DemoWeb.Models
{
    public class Customer
    {
        public Customer()
        {
            OrderProes = new HashSet<OrderPro>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Display(Name = "Mã khách hàng")]
        public int IDCus { get; set; }

        [Display(Name = "Tên khách hàng")]
        [Required(ErrorMessage = "Tên khách hàng không được để trống")]
        public string NameCus { get; set; }

        [Display(Name = "Số điện thoại")]
        public string PhoneCus { get; set; }

        [Display(Name = "Email")]
        [EmailAddress(ErrorMessage = "Email không hợp lệ")]
        public string EmailCus { get; set; }

        public virtual ICollection<OrderPro> OrderProes { get; set; }
    }
}
