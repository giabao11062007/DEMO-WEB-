using System;
using System.Collections.Generic;
using System.Text.Json;

namespace DemoWeb.Models
{
    public class CartItem
    {
        public Product _product { get; set; }
        public int _quantity { get; set; }
    }

    public class Cart
    {
        public List<CartItem> Items { get; set; }

        public Cart()
        {
            Items = new List<CartItem>();
        }

        // Thêm sản phẩm vào giỏ hàng
        public void Add_Product_Cart(Product pro)
        {
            var item = Items.Find(s => s._product.ProductID == pro.ProductID);
            if (item == null)
            {
                Items.Add(new CartItem { _product = pro, _quantity = 1 });
            }
            else
            {
                item._quantity += 1;
            }
        }

        // Cập nhật số lượng sản phẩm
        public void Update_quantity(int id, int quantity)
        {
            var item = Items.Find(s => s._product.ProductID == id);
            if (item != null)
            {
                item._quantity = quantity;
                if (item._quantity <= 0) Items.Remove(item);
            }
        }

        // Xóa sản phẩm khỏi giỏ hàng
        public void Remove_CartItem(int id)
        {
            var item = Items.Find(s => s._product.ProductID == id);
            if (item != null) Items.Remove(item);
        }

        // Tổng số lượng sản phẩm trong giỏ
        public int Total_quantity()
        {
            int total = 0;
            foreach (var item in Items) total += item._quantity;
            return total;
        }

        // Tổng tiền giỏ hàng
        public decimal Total_price()
        {
            decimal total = 0;
            foreach (var item in Items)
                total += (item._product.Price ?? 0) * item._quantity;
            return total;
        }

        // Xóa toàn bộ giỏ hàng
        public void ClearCart()
        {
            Items.Clear();
        }
    }
}
