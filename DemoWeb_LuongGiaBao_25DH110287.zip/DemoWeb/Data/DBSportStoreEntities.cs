using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using DemoWeb.Models;

namespace DemoWeb.Data
{
    public class DBSportStoreEntities : DbContext
    {
        private static readonly object _sqlSyncLock = new object();

        public const string DefaultSqlServerConnection =
            "Server=DESKTOP-8SMUIKJ\\SQLEXPRESS03;Database=DBSportStore;Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=True;";

        public DBSportStoreEntities() : base()
        {
        }

        public DBSportStoreEntities(DbContextOptions<DBSportStoreEntities> options) : base(options)
        {
        }

        public DbSet<AdminUser> AdminUsers { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<OrderPro> OrderProes { get; set; }
        public DbSet<OrderDetail> OrderDetails { get; set; }

        public static string ResolveProjectRoot(string preferredRoot = null)
        {
            string[] candidates = new[]
            {
                preferredRoot,
                Directory.GetCurrentDirectory(),
                AppContext.BaseDirectory
            };

            foreach (var startDir in candidates)
            {
                if (string.IsNullOrEmpty(startDir) || !Directory.Exists(startDir))
                    continue;

                var dir = new DirectoryInfo(startDir);
                for (int i = 0; i < 6 && dir != null; i++)
                {
                    if (File.Exists(Path.Combine(dir.FullName, "DemoWeb.csproj")) ||
                        File.Exists(Path.Combine(dir.FullName, "DBSportStore.sql")))
                    {
                        return dir.FullName;
                    }
                    dir = dir.Parent;
                }
            }

            return !string.IsNullOrEmpty(preferredRoot) ? preferredRoot : Directory.GetCurrentDirectory();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(DefaultSqlServerConnection);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Table mapping (khớp với bảng trong SQL Server dbo.*)
            modelBuilder.Entity<AdminUser>().ToTable("AdminUser");
            modelBuilder.Entity<Category>().ToTable("Category");
            modelBuilder.Entity<Product>().ToTable("Product");
            modelBuilder.Entity<Customer>().ToTable("Customer");
            modelBuilder.Entity<OrderPro>().ToTable("OrderPro");
            modelBuilder.Entity<OrderDetail>().ToTable("OrderDetail");

            modelBuilder.Entity<Category>()
                .Property(c => c.IDCate)
                .HasMaxLength(50)
                .IsRequired();

            // Relationships
            modelBuilder.Entity<Product>()
                .HasOne(p => p.Category1)
                .WithMany(c => c.Products)
                .HasPrincipalKey(c => c.IDCate)
                .HasForeignKey(p => p.Category)
                .IsRequired(false)
                .OnDelete(DeleteBehavior.SetNull);

            modelBuilder.Entity<OrderDetail>()
                .HasOne(d => d.Product)
                .WithMany(p => p.OrderDetails)
                .HasForeignKey(d => d.IDProduct)
                .IsRequired(false)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<OrderDetail>()
                .HasOne(d => d.OrderPro)
                .WithMany(o => o.OrderDetails)
                .HasForeignKey(d => d.IDOrder)
                .IsRequired(false)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<OrderPro>()
                .HasOne(o => o.Customer)
                .WithMany(c => c.OrderProes)
                .HasForeignKey(o => o.IDCus)
                .IsRequired(false)
                .OnDelete(DeleteBehavior.SetNull);
        }

        public override int SaveChanges()
        {
            var result = base.SaveChanges();
            if (result > 0)
            {
                SyncSqlScriptSafe();
            }
            return result;
        }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            var result = await base.SaveChangesAsync(cancellationToken);
            if (result > 0)
            {
                SyncSqlScriptSafe();
            }
            return result;
        }

        /// <summary>
        /// Tự động đồng bộ dữ liệu từ SQL Server ra file DBSportStore.sql (chuẩn T-SQL cho SSMS)
        /// mỗi khi có thay đổi dữ liệu trong ứng dụng.
        /// </summary>
        public void SyncSqlScriptSafe()
        {
            try
            {
                var sqlPath = Path.Combine(ResolveProjectRoot(), "DBSportStore.sql");

                var admins = AdminUsers.AsNoTracking().OrderBy(x => x.ID).ToList();
                var categories = Categories.AsNoTracking().OrderBy(x => x.Id).ToList();
                var products = Products.AsNoTracking().OrderBy(x => x.ProductID).ToList();
                var customers = Customers.AsNoTracking().OrderBy(x => x.IDCus).ToList();
                var orders = OrderProes.AsNoTracking().OrderBy(x => x.ID).ToList();
                var orderDetails = OrderDetails.AsNoTracking().OrderBy(x => x.ID).ToList();

                var sb = new StringBuilder();
                sb.AppendLine("-- ============================================================");
                sb.AppendLine("-- T-SQL SCRIPT CHO MICROSOFT SQL SERVER (SSMS)");
                sb.AppendLine("-- Server: DESKTOP-8SMUIKJ\\SQLEXPRESS03 | Database: DBSportStore");
                sb.AppendLine("-- ============================================================");
                sb.AppendLine("IF DB_ID(N'DBSportStore') IS NULL");
                sb.AppendLine("BEGIN");
                sb.AppendLine("    CREATE DATABASE [DBSportStore];");
                sb.AppendLine("END");
                sb.AppendLine("GO");
                sb.AppendLine();
                sb.AppendLine("USE [DBSportStore];");
                sb.AppendLine("GO");
                sb.AppendLine();
                sb.AppendLine("IF OBJECT_ID(N'dbo.OrderDetail', N'U') IS NOT NULL DROP TABLE dbo.OrderDetail;");
                sb.AppendLine("IF OBJECT_ID(N'dbo.OrderPro', N'U')    IS NOT NULL DROP TABLE dbo.OrderPro;");
                sb.AppendLine("IF OBJECT_ID(N'dbo.Customer', N'U')    IS NOT NULL DROP TABLE dbo.Customer;");
                sb.AppendLine("IF OBJECT_ID(N'dbo.Product', N'U')     IS NOT NULL DROP TABLE dbo.Product;");
                sb.AppendLine("IF OBJECT_ID(N'dbo.Category', N'U')    IS NOT NULL DROP TABLE dbo.Category;");
                sb.AppendLine("IF OBJECT_ID(N'dbo.AdminUser', N'U')   IS NOT NULL DROP TABLE dbo.AdminUser;");
                sb.AppendLine("GO");
                sb.AppendLine();
                sb.AppendLine("-- ============================================================");
                sb.AppendLine("-- BẢNG 1: AdminUser - Quản lý tài khoản đăng nhập hệ thống");
                sb.AppendLine("-- ============================================================");
                sb.AppendLine("CREATE TABLE dbo.AdminUser (");
                sb.AppendLine("    ID           INT IDENTITY(1,1) NOT NULL PRIMARY KEY,");
                sb.AppendLine("    NameUser     NVARCHAR(50)      NOT NULL,");
                sb.AppendLine("    RoleUser     NVARCHAR(50)      NULL,");
                sb.AppendLine("    PasswordUser NVARCHAR(100)     NOT NULL");
                sb.AppendLine(");");
                sb.AppendLine("GO");
                sb.AppendLine();
                sb.AppendLine("-- ============================================================");
                sb.AppendLine("-- BẢNG 2: Category - Danh mục thể loại sản phẩm");
                sb.AppendLine("-- ============================================================");
                sb.AppendLine("CREATE TABLE dbo.Category (");
                sb.AppendLine("    Id       INT IDENTITY(1,1) NOT NULL PRIMARY KEY,");
                sb.AppendLine("    IDCate   NVARCHAR(50)      NOT NULL UNIQUE,");
                sb.AppendLine("    NameCate NVARCHAR(100)     NOT NULL");
                sb.AppendLine(");");
                sb.AppendLine("GO");
                sb.AppendLine();
                sb.AppendLine("-- ============================================================");
                sb.AppendLine("-- BẢNG 3: Product - Danh sách sản phẩm");
                sb.AppendLine("-- ============================================================");
                sb.AppendLine("CREATE TABLE dbo.Product (");
                sb.AppendLine("    ProductID     INT IDENTITY(1,1) NOT NULL PRIMARY KEY,");
                sb.AppendLine("    NamePro       NVARCHAR(200)     NOT NULL,");
                sb.AppendLine("    DecriptionPro NVARCHAR(1000)    NULL,");
                sb.AppendLine("    Category      NVARCHAR(50)      NULL,");
                sb.AppendLine("    Price         DECIMAL(18,2)     NULL,");
                sb.AppendLine("    Image_Pro     NVARCHAR(500)     NULL,");
                sb.AppendLine("    Quantity      INT               NULL,");
                sb.AppendLine("    CONSTRAINT FK_Product_Category FOREIGN KEY (Category) REFERENCES dbo.Category (IDCate) ON DELETE SET NULL");
                sb.AppendLine(");");
                sb.AppendLine("GO");
                sb.AppendLine();
                sb.AppendLine("-- ============================================================");
                sb.AppendLine("-- BẢNG 4: Customer - Thông tin khách hàng đặt hàng");
                sb.AppendLine("-- ============================================================");
                sb.AppendLine("CREATE TABLE dbo.Customer (");
                sb.AppendLine("    IDCus    INT IDENTITY(1,1) NOT NULL PRIMARY KEY,");
                sb.AppendLine("    NameCus  NVARCHAR(200)     NOT NULL,");
                sb.AppendLine("    PhoneCus NVARCHAR(50)      NULL,");
                sb.AppendLine("    EmailCus NVARCHAR(200)     NULL");
                sb.AppendLine(");");
                sb.AppendLine("GO");
                sb.AppendLine();
                sb.AppendLine("-- ============================================================");
                sb.AppendLine("-- BẢNG 5: OrderPro - Hóa đơn đặt hàng");
                sb.AppendLine("-- ============================================================");
                sb.AppendLine("CREATE TABLE dbo.OrderPro (");
                sb.AppendLine("    ID              INT IDENTITY(1,1) NOT NULL PRIMARY KEY,");
                sb.AppendLine("    DateOrder       DATETIME2         NULL,");
                sb.AppendLine("    IDCus           INT               NULL,");
                sb.AppendLine("    AddressDelivery NVARCHAR(500)     NULL,");
                sb.AppendLine("    PaymentStatus   NVARCHAR(100)     NULL,");
                sb.AppendLine("    PaymentMethod   NVARCHAR(100)     NULL,");
                sb.AppendLine("    ShippingMethod  NVARCHAR(100)     NULL,");
                sb.AppendLine("    OrderStatus     NVARCHAR(100)     NULL,");
                sb.AppendLine("    TotalAmount     DECIMAL(18,2)     NULL,");
                sb.AppendLine("    CONSTRAINT FK_OrderPro_Customer FOREIGN KEY (IDCus) REFERENCES dbo.Customer (IDCus) ON DELETE SET NULL");
                sb.AppendLine(");");
                sb.AppendLine("GO");
                sb.AppendLine();
                sb.AppendLine("-- ============================================================");
                sb.AppendLine("-- BẢNG 6: OrderDetail - Chi tiết từng dòng sản phẩm trong hóa đơn");
                sb.AppendLine("-- ============================================================");
                sb.AppendLine("CREATE TABLE dbo.OrderDetail (");
                sb.AppendLine("    ID        INT IDENTITY(1,1) NOT NULL PRIMARY KEY,");
                sb.AppendLine("    IDProduct INT               NULL,");
                sb.AppendLine("    IDOrder   INT               NULL,");
                sb.AppendLine("    Quantity  INT               NULL,");
                sb.AppendLine("    UnitPrice DECIMAL(18,2)     NULL,");
                sb.AppendLine("    CONSTRAINT FK_OrderDetail_Product  FOREIGN KEY (IDProduct) REFERENCES dbo.Product (ProductID) ON DELETE CASCADE,");
                sb.AppendLine("    CONSTRAINT FK_OrderDetail_OrderPro FOREIGN KEY (IDOrder)   REFERENCES dbo.OrderPro (ID)       ON DELETE CASCADE");
                sb.AppendLine(");");
                sb.AppendLine("GO");
                sb.AppendLine();
                sb.AppendLine("-- ============================================================");
                sb.AppendLine("-- DỮ LIỆU ĐỒNG BỘ TỰ ĐỘNG");
                sb.AppendLine("-- ============================================================");

                if (admins.Any())
                {
                    sb.AppendLine("SET IDENTITY_INSERT dbo.AdminUser ON;");
                    foreach (var a in admins)
                    {
                        sb.AppendLine($"INSERT INTO dbo.AdminUser (ID, NameUser, RoleUser, PasswordUser) VALUES ({a.ID}, {SqlStr(a.NameUser)}, {SqlStr(a.RoleUser)}, {SqlStr(a.PasswordUser)});");
                    }
                    sb.AppendLine("SET IDENTITY_INSERT dbo.AdminUser OFF;");
                    sb.AppendLine("GO");
                    sb.AppendLine();
                }

                if (categories.Any())
                {
                    sb.AppendLine("SET IDENTITY_INSERT dbo.Category ON;");
                    foreach (var c in categories)
                    {
                        sb.AppendLine($"INSERT INTO dbo.Category (Id, IDCate, NameCate) VALUES ({c.Id}, {SqlStr(c.IDCate)}, {SqlStr(c.NameCate)});");
                    }
                    sb.AppendLine("SET IDENTITY_INSERT dbo.Category OFF;");
                    sb.AppendLine("GO");
                    sb.AppendLine();
                }

                if (products.Any())
                {
                    sb.AppendLine("SET IDENTITY_INSERT dbo.Product ON;");
                    foreach (var p in products)
                    {
                        sb.AppendLine($"INSERT INTO dbo.Product (ProductID, NamePro, DecriptionPro, Category, Price, Image_Pro, Quantity) VALUES ({p.ProductID}, {SqlStr(p.NamePro)}, {SqlStr(p.DecriptionPro)}, {SqlStr(p.Category)}, {SqlDec(p.Price)}, {SqlStr(p.Image_Pro)}, {SqlInt(p.Quantity)});");
                    }
                    sb.AppendLine("SET IDENTITY_INSERT dbo.Product OFF;");
                    sb.AppendLine("GO");
                    sb.AppendLine();
                }

                if (customers.Any())
                {
                    sb.AppendLine("SET IDENTITY_INSERT dbo.Customer ON;");
                    foreach (var cus in customers)
                    {
                        sb.AppendLine($"INSERT INTO dbo.Customer (IDCus, NameCus, PhoneCus, EmailCus) VALUES ({cus.IDCus}, {SqlStr(cus.NameCus)}, {SqlStr(cus.PhoneCus)}, {SqlStr(cus.EmailCus)});");
                    }
                    sb.AppendLine("SET IDENTITY_INSERT dbo.Customer OFF;");
                    sb.AppendLine("GO");
                    sb.AppendLine();
                }

                if (orders.Any())
                {
                    sb.AppendLine("SET IDENTITY_INSERT dbo.OrderPro ON;");
                    foreach (var o in orders)
                    {
                        var dateStr = o.DateOrder.HasValue ? o.DateOrder.Value.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) : null;
                        sb.AppendLine($"INSERT INTO dbo.OrderPro (ID, DateOrder, IDCus, AddressDelivery, PaymentStatus, PaymentMethod, ShippingMethod, OrderStatus, TotalAmount) VALUES ({o.ID}, {SqlDate(dateStr)}, {SqlInt(o.IDCus)}, {SqlStr(o.AddressDelivery)}, {SqlStr(o.PaymentStatus)}, {SqlStr(o.PaymentMethod)}, {SqlStr(o.ShippingMethod)}, {SqlStr(o.OrderStatus)}, {SqlDec(o.TotalAmount)});");
                    }
                    sb.AppendLine("SET IDENTITY_INSERT dbo.OrderPro OFF;");
                    sb.AppendLine("GO");
                    sb.AppendLine();
                }

                if (orderDetails.Any())
                {
                    sb.AppendLine("SET IDENTITY_INSERT dbo.OrderDetail ON;");
                    foreach (var od in orderDetails)
                    {
                        sb.AppendLine($"INSERT INTO dbo.OrderDetail (ID, IDProduct, IDOrder, Quantity, UnitPrice) VALUES ({od.ID}, {SqlInt(od.IDProduct)}, {SqlInt(od.IDOrder)}, {SqlInt(od.Quantity)}, {SqlDec(od.UnitPrice)});");
                    }
                    sb.AppendLine("SET IDENTITY_INSERT dbo.OrderDetail OFF;");
                    sb.AppendLine("GO");
                }

                lock (_sqlSyncLock)
                {
                    // Dùng UTF-8 có BOM để SSMS mở lên hiển thị đúng tiếng Việt có dấu
                    File.WriteAllText(sqlPath, sb.ToString(), new UTF8Encoding(true));
                }
            }
            catch
            {
                // Không làm gián đoạn giao dịch chính nếu file SQL đang bị khóa bởi SSMS/editor
            }
        }

        private static string SqlStr(string value)
        {
            if (value == null) return "NULL";
            return "N'" + value.Replace("'", "''") + "'";
        }

        private static string SqlDate(string value)
        {
            if (value == null) return "NULL";
            return "'" + value.Replace("'", "''") + "'";
        }

        private static string SqlInt(int? value)
        {
            return value.HasValue ? value.Value.ToString(CultureInfo.InvariantCulture) : "NULL";
        }

        private static string SqlDec(decimal? value)
        {
            return value.HasValue ? value.Value.ToString("0.00", CultureInfo.InvariantCulture) : "NULL";
        }
    }
}
