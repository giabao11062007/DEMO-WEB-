using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DemoWeb.Data;
using DemoWeb.Models;

namespace DemoWeb.Controllers
{
    public class OrdersController : Controller
    {
        private readonly DBSportStoreEntities database;

        public OrdersController(DBSportStoreEntities db)
        {
            database = db;
        }

        // GET: Orders/Index - Trang Danh sách đơn hàng (Theo Slide 1 PPTX)
        // Cho phép tìm theo Tên khách hàng, Trạng thái thanh toán, Ngày đặt hàng
        // Phân trang 15 đơn hàng/trang. Nếu không có đơn hàng phù hợp -> hiển thị: KHÔNG CÓ
        public async Task<IActionResult> Index(string searchCustomer, string paymentStatus, DateTime? orderDate, int? page)
        {
            ViewBag.SearchCustomer = searchCustomer;
            ViewBag.PaymentStatus = paymentStatus;
            ViewBag.OrderDate = orderDate?.ToString("yyyy-MM-dd");

            var query = database.OrderProes
                .Include(o => o.Customer)
                .Include(o => o.OrderDetails)
                    .ThenInclude(od => od.Product)
                .AsQueryable();

            // Lọc theo Tên khách hàng
            if (!string.IsNullOrWhiteSpace(searchCustomer))
            {
                query = query.Where(o => o.Customer != null && o.Customer.NameCus.Contains(searchCustomer));
            }

            // Lọc theo Trạng thái thanh toán
            if (!string.IsNullOrWhiteSpace(paymentStatus) && paymentStatus != "Tất cả")
            {
                query = query.Where(o => o.PaymentStatus == paymentStatus);
            }

            // Lọc theo Ngày đặt hàng
            if (orderDate.HasValue)
            {
                var targetDate = orderDate.Value.Date;
                query = query.Where(o => o.DateOrder.HasValue && o.DateOrder.Value.Date == targetDate);
            }

            var orderList = await query.OrderByDescending(o => o.ID).ToListAsync();

            // Tính tổng tiền nếu chưa có TotalAmount
            foreach (var ord in orderList)
            {
                if (ord.TotalAmount == null || ord.TotalAmount == 0)
                {
                    ord.TotalAmount = ord.OrderDetails?.Sum(od => (od.UnitPrice ?? 0) * (od.Quantity ?? 0)) ?? 0;
                }
            }

            int pageSize = 15; // Theo yêu cầu slide 1: 15 đơn hàng/trang
            int pageNumber = page ?? 1;

            var pagedOrders = PagedList<OrderPro>.Create(orderList, pageNumber, pageSize);

            return View(pagedOrders);
        }

        // GET: Orders/DetailedOrder/5 - Trang Chi tiết đơn hàng (Theo Slide 2 PPTX)
        public async Task<IActionResult> DetailedOrder(int? id)
        {
            if (id == null) return NotFound();

            var order = await database.OrderProes
                .Include(o => o.Customer)
                .Include(o => o.OrderDetails)
                    .ThenInclude(od => od.Product)
                .FirstOrDefaultAsync(o => o.ID == id);

            if (order == null) return NotFound();

            if (order.TotalAmount == null || order.TotalAmount == 0)
            {
                order.TotalAmount = order.OrderDetails?.Sum(od => (od.UnitPrice ?? 0) * (od.Quantity ?? 0)) ?? 0;
            }

            return View(order);
        }

        // GET: Orders/UpdateStatus/5 - Cập nhật trạng thái đơn hàng (Theo Slide 2 PPTX)
        public async Task<IActionResult> UpdateStatus(int? id)
        {
            if (id == null) return NotFound();

            var order = await database.OrderProes
                .Include(o => o.Customer)
                .FirstOrDefaultAsync(o => o.ID == id);

            if (order == null) return NotFound();

            return View(order);
        }

        // POST: Orders/UpdateStatus/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateStatus(int id, string paymentStatus, string paymentMethod, string shippingMethod, string orderStatus)
        {
            var order = await database.OrderProes.FindAsync(id);
            if (order == null) return NotFound();

            order.PaymentStatus = paymentStatus;
            order.PaymentMethod = paymentMethod;
            order.ShippingMethod = shippingMethod;
            order.OrderStatus = orderStatus;

            await database.SaveChangesAsync();
            TempData["SuccessOrderUpdate"] = $"Cập nhật trạng thái cho Đơn hàng #{id} thành công!";

            return RedirectToAction(nameof(DetailedOrder), new { id = id });
        }
    }
}
