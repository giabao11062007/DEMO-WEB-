using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using DemoWeb.Data;
using DemoWeb.Models;

namespace DemoWeb.Controllers
{
    public class OrderDetailController : Controller
    {
        private readonly DBSportStoreEntities database;

        public OrderDetailController(DBSportStoreEntities db)
        {
            database = db;
        }

        // Action hiển thị top 5 sản phẩm có số lượng bán nhiều nhất (Lab 07a)
        public ActionResult GroupByTop5()
        {
            List<OrderDetail> orderD = database.OrderDetails.ToList();
            List<Product> proList = database.Products.ToList();

            var query = from od in orderD
                        join p in proList on od.IDProduct equals p.ProductID into tbl
                        from p in tbl.DefaultIfEmpty()
                        group od by new
                        {
                            idPro = od.IDProduct,
                            namePro = p != null ? p.NamePro : ("SP #" + od.IDProduct),
                            imagePro = p != null ? p.Image_Pro : "/Content/images/add.png",
                            price = p != null ? p.Price : (decimal?)0m
                        } into gr
                        orderby gr.Sum(s => s.Quantity) descending
                        select new ViewModel
                        {
                            IDPro = gr.Key.idPro,
                            NamePro = gr.Key.namePro,
                            ImgPro = gr.Key.imagePro,
                            pricePro = (decimal)(gr.Key.price ?? 0),
                            Sum_Quantity = gr.Sum(s => s.Quantity)
                        };

            return View(query.Take(5).ToList());
        }
    }
}
