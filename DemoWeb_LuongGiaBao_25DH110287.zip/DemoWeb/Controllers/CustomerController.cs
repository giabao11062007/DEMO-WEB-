using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DemoWeb.Data;
using DemoWeb.Models;

namespace DemoWeb.Controllers
{
    public class CustomerController : Controller
    {
        private readonly DBSportStoreEntities database;

        public CustomerController(DBSportStoreEntities db)
        {
            database = db;
        }

        // GET: Customer/Index - Danh sách khách hàng (không có nút Thêm/Sửa/Xóa)
        public async Task<IActionResult> Index()
        {
            return View(await database.Customers.ToListAsync());
        }

        // GET: Customer/Details/5 - Thông tin KH + danh sách đơn hàng
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var customer = await database.Customers
                .Include(c => c.OrderProes)
                    .ThenInclude(o => o.OrderDetails)
                        .ThenInclude(od => od.Product)
                .FirstOrDefaultAsync(c => c.IDCus == id);

            if (customer == null) return NotFound();

            return View(customer);
        }

        // GET: Customer/Create (Lab 06b page 3)
        public IActionResult Create()
        {
            return View();
        }

        // POST: Customer/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Customer customer)
        {
            if (ModelState.IsValid)
            {
                database.Customers.Add(customer);
                await database.SaveChangesAsync();

                HttpContext.Session.SetInt32("CustomerID", customer.IDCus);
                HttpContext.Session.SetString("CustomerName", customer.NameCus);

                TempData["CartMessage"] = $"Đăng ký thành công khách hàng {customer.NameCus}! Mã khách hàng của bạn là: {customer.IDCus}";
                TempData["SuccessMessage"] = $"Đăng ký thành công khách hàng! Mã khách hàng (Code Customer) của bạn là: {customer.IDCus}";
                return RedirectToAction("ShowCart", "ShoppingCart");
            }
            return View(customer);
        }
    }
}
