using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DemoWeb.Data;
using DemoWeb.Models;

namespace DemoWeb.Controllers
{
    public class AdminUserController : Controller
    {
        private readonly DBSportStoreEntities database;

        public AdminUserController(DBSportStoreEntities db)
        {
            database = db;
        }

        // GET: AdminUser/Index - Danh sách người quản trị + tab danh sách tài khoản User đã đăng ký
        public async Task<IActionResult> Index()
        {
            var allUsers = await database.AdminUsers.OrderBy(u => u.ID).ToListAsync();
            // Tab 1: Danh sách người quản trị (Administrator, Manager, Staff...)
            var adminList = allUsers
                .Where(u => u.RoleUser == null || !u.RoleUser.Equals("User", System.StringComparison.OrdinalIgnoreCase))
                .ToList();

            // Tab 2: Danh sách tài khoản người dùng (User) đã đăng ký
            ViewBag.UserAccounts = allUsers
                .Where(u => u.RoleUser != null && u.RoleUser.Equals("User", System.StringComparison.OrdinalIgnoreCase))
                .ToList();

            return View(adminList);
        }

        // GET: AdminUser/Create - Thêm tài khoản quản trị
        public IActionResult Create()
        {
            return View();
        }

        // POST: AdminUser/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(AdminUser adminUser)
        {
            if (ModelState.IsValid)
            {
                var exists = await database.AdminUsers.AnyAsync(u => u.NameUser == adminUser.NameUser);
                if (exists)
                {
                    ModelState.AddModelError("NameUser", "Tên đăng nhập này đã tồn tại!");
                    return View(adminUser);
                }

                database.AdminUsers.Add(adminUser);
                await database.SaveChangesAsync();

                if (adminUser.RoleUser != null && adminUser.RoleUser.Equals("User", System.StringComparison.OrdinalIgnoreCase))
                {
                    var hasCustomer = await database.Customers.AnyAsync(c => c.NameCus == adminUser.NameUser);
                    if (!hasCustomer)
                    {
                        database.Customers.Add(new Customer
                        {
                            NameCus = adminUser.NameUser,
                            PhoneCus = "",
                            EmailCus = ""
                        });
                        await database.SaveChangesAsync();
                    }
                }

                TempData["SuccessAdminUser"] = "Thêm tài khoản thành công!";
                return RedirectToAction(nameof(Index));
            }
            return View(adminUser);
        }

        // GET: AdminUser/Edit/5 - Sửa tài khoản quản trị
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var adminUser = await database.AdminUsers.FindAsync(id);
            if (adminUser == null) return NotFound();

            return View(adminUser);
        }

        // POST: AdminUser/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, AdminUser adminUser)
        {
            if (id != adminUser.ID) return NotFound();

            if (ModelState.IsValid)
            {
                var exists = await database.AdminUsers.AnyAsync(u => u.NameUser == adminUser.NameUser && u.ID != id);
                if (exists)
                {
                    ModelState.AddModelError("NameUser", "Tên đăng nhập này đã tồn tại!");
                    return View(adminUser);
                }

                try
                {
                    database.Update(adminUser);
                    await database.SaveChangesAsync();
                    TempData["SuccessAdminUser"] = "Cập nhật tài khoản quản trị thành công!";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!database.AdminUsers.Any(e => e.ID == adminUser.ID))
                        return NotFound();
                    else
                        throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(adminUser);
        }

        // GET: AdminUser/Delete/5 - Xóa tài khoản quản trị
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var adminUser = await database.AdminUsers.FindAsync(id);
            if (adminUser == null) return NotFound();

            return View(adminUser);
        }

        // POST: AdminUser/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var adminUser = await database.AdminUsers.FindAsync(id);
            if (adminUser != null)
            {
                // Ngăn xóa tài khoản admin gốc
                if (adminUser.NameUser.Equals("admin", System.StringComparison.OrdinalIgnoreCase))
                {
                    TempData["ErrorAdminUser"] = "Không thể xóa tài khoản Administrator mặc định của hệ thống!";
                    return RedirectToAction(nameof(Index));
                }

                database.AdminUsers.Remove(adminUser);
                await database.SaveChangesAsync();
                TempData["SuccessAdminUser"] = "Xóa tài khoản quản trị thành công!";
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
