using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DemoWeb.Data;
using DemoWeb.Models;

namespace DemoWeb.Controllers
{
    public class InventoryController : Controller
    {
        private readonly DBSportStoreEntities database;

        public InventoryController(DBSportStoreEntities db)
        {
            database = db;
        }

        // GET: Inventory/Index - Thống kê kho hàng thành 2 phần: Hàng tồn và Hàng cần nhập
        public async Task<IActionResult> Index()
        {
            var allProducts = await database.Products
                .Include(p => p.Category1)
                .OrderBy(p => p.ProductID)
                .ToListAsync();

            // 1. Danh sách hàng tồn: số lượng tồn > 0
            var inStockProducts = allProducts.Where(p => (p.Quantity ?? 0) > 0).ToList();

            // 2. Danh sách hàng cần nhập: số lượng tồn = 0 (hoặc <= 0)
            var outOfStockProducts = allProducts.Where(p => (p.Quantity ?? 0) <= 0).ToList();

            ViewBag.InStockProducts = inStockProducts;
            ViewBag.OutOfStockProducts = outOfStockProducts;

            return View(allProducts);
        }
    }
}
