using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DemoWeb.Data;
using DemoWeb.Models;

namespace DemoWeb.Controllers
{
    public class ProductController : Controller
    {
        private readonly DBSportStoreEntities database;
        private readonly IWebHostEnvironment _environment;

        public ProductController(DBSportStoreEntities db, IWebHostEnvironment environment)
        {
            database = db;
            _environment = environment;
        }

        // GET: Product/Index (Khách hàng)
        public async Task<IActionResult> Index(string category, string searchString, int? page)
        {
            ViewBag.CurrentCategory = category;
            ViewBag.SearchString = searchString;

            var products = database.Products
                .Include(p => p.Category1)
                .AsQueryable();

            if (!string.IsNullOrEmpty(category))
            {
                products = products.Where(p => p.Category == category);
            }

            if (!string.IsNullOrEmpty(searchString))
            {
                products = products.Where(p => p.NamePro.Contains(searchString));
            }

            int pageSize = 6;
            int pageNumber = page ?? 1;

            var proList = await products.OrderByDescending(p => p.ProductID).ToListAsync();
            var pagedProducts = PagedList<Product>.Create(proList, pageNumber, pageSize);

            return View(pagedProducts);
        }

        // GET: Product/AdminIndex - Trang Quản lý hàng hóa Admin: Chỉ hiện 4-5 cột dữ liệu chính (Tên, Ảnh, Giá, Tồn kho, Chủng loại)
        public async Task<IActionResult> AdminIndex(string category, string searchString, int? page)
        {
            ViewBag.CurrentCategory = category;
            ViewBag.SearchString = searchString;

            var products = database.Products
                .Include(p => p.Category1)
                .AsQueryable();

            if (!string.IsNullOrEmpty(category))
            {
                products = products.Where(p => p.Category == category);
            }

            if (!string.IsNullOrEmpty(searchString))
            {
                products = products.Where(p => p.NamePro.Contains(searchString));
            }

            int pageSize = 10;
            int pageNumber = page ?? 1;

            var proList = await products.OrderByDescending(p => p.ProductID).ToListAsync();
            var pagedProducts = PagedList<Product>.Create(proList, pageNumber, pageSize);

            return View(pagedProducts);
        }

        // GET: Product/Details/5 (Customer - Có nút MUA HÀNG)
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var product = await database.Products
                .Include(p => p.Category1)
                .FirstOrDefaultAsync(m => m.ProductID == id);

            if (product == null) return NotFound();

            ViewBag.ShowBuyButton = true;
            return View(product);
        }

        // GET: Product/AdminDetails/5 (Admin - Không có nút MUA HÀNG, format giống Customer)
        public async Task<IActionResult> AdminDetails(int? id)
        {
            if (id == null) return NotFound();

            var product = await database.Products
                .Include(p => p.Category1)
                .FirstOrDefaultAsync(m => m.ProductID == id);

            if (product == null) return NotFound();

            ViewBag.ShowBuyButton = false;
            return View("AdminDetails", product);
        }

        // GET: Product/Create
        public IActionResult Create()
        {
            ViewBag.Category = new SelectList(database.Categories, "IDCate", "NameCate");
            return View();
        }

        // POST: Product/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product product)
        {
            if (string.IsNullOrWhiteSpace(product.Category))
            {
                product.Category = null;
            }

            if (ModelState.IsValid)
            {
                if (product.UploadImage != null)
                {
                    string fileName = Path.GetFileName(product.UploadImage.FileName);
                    string uploadsFolder = Path.Combine(_environment.WebRootPath, "Content", "images");
                    if (!Directory.Exists(uploadsFolder)) Directory.CreateDirectory(uploadsFolder);
                    string filePath = Path.Combine(uploadsFolder, fileName);
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await product.UploadImage.CopyToAsync(stream);
                    }
                    product.Image_Pro = "/Content/images/" + fileName;
                }
                else if (string.IsNullOrEmpty(product.Image_Pro))
                {
                    product.Image_Pro = "/Content/images/add.png";
                }

                database.Products.Add(product);
                await database.SaveChangesAsync();
                return RedirectToAction(nameof(AdminIndex));
            }

            ViewBag.Category = new SelectList(database.Categories, "IDCate", "NameCate", product.Category);
            return View(product);
        }

        // GET: Product/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var product = await database.Products.FindAsync(id);
            if (product == null) return NotFound();

            ViewBag.Category = new SelectList(database.Categories, "IDCate", "NameCate", product.Category);
            return View(product);
        }

        // POST: Product/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Product product)
        {
            if (id != product.ProductID) return NotFound();

            if (string.IsNullOrWhiteSpace(product.Category))
            {
                product.Category = null;
            }

            if (ModelState.IsValid)
            {
                try
                {
                    if (product.UploadImage != null)
                    {
                        string fileName = Path.GetFileName(product.UploadImage.FileName);
                        string uploadsFolder = Path.Combine(_environment.WebRootPath, "Content", "images");
                        if (!Directory.Exists(uploadsFolder)) Directory.CreateDirectory(uploadsFolder);
                        string filePath = Path.Combine(uploadsFolder, fileName);
                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            await product.UploadImage.CopyToAsync(stream);
                        }
                        product.Image_Pro = "/Content/images/" + fileName;
                    }

                    database.Update(product);
                    await database.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!database.Products.Any(e => e.ProductID == product.ProductID))
                        return NotFound();
                    else
                        throw;
                }
                return RedirectToAction(nameof(AdminIndex));
            }

            ViewBag.Category = new SelectList(database.Categories, "IDCate", "NameCate", product.Category);
            return View(product);
        }

        // GET: Product/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var product = await database.Products
                .Include(p => p.Category1)
                .FirstOrDefaultAsync(m => m.ProductID == id);
            if (product == null) return NotFound();

            return View(product);
        }

        // POST: Product/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var product = await database.Products
                .Include(p => p.OrderDetails)
                .FirstOrDefaultAsync(p => p.ProductID == id);

            if (product != null)
            {
                // Kiểm tra ràng buộc dữ liệu: Nếu sản phẩm đã phát sinh đơn hàng
                if (product.OrderDetails != null && product.OrderDetails.Any())
                {
                    return Content("Không thể xóa sản phẩm này vì đã có đơn hàng đặt mua liên quan!");
                }

                database.Products.Remove(product);
                await database.SaveChangesAsync();
            }
            return RedirectToAction(nameof(AdminIndex));
        }

        // GET: Product/SearchOption (Lab 07a)
        public IActionResult SearchOption(decimal? minPrice, decimal? maxPrice)
        {
            ViewBag.MinPrice = minPrice;
            ViewBag.MaxPrice = maxPrice;

            var products = database.Products.Include(p => p.Category1).AsQueryable();

            if (minPrice.HasValue)
            {
                products = products.Where(p => p.Price >= minPrice.Value);
            }
            if (maxPrice.HasValue)
            {
                products = products.Where(p => p.Price <= maxPrice.Value);
            }

            return View(products.ToList());
        }
    }
}
