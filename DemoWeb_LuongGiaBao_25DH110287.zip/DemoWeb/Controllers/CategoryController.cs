using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DemoWeb.Data;
using DemoWeb.Models;

namespace DemoWeb.Controllers
{
    public class CategoryController : Controller
    {
        private readonly DBSportStoreEntities database;

        public CategoryController(DBSportStoreEntities db)
        {
            database = db;
        }

        // GET: Category/Index
        public async Task<IActionResult> Index()
        {
            var categories = await database.Categories
                .Include(c => c.Products)
                .ToListAsync();
            return View(categories);
        }

        // GET: Category/Details/5 - Hiển thị thông tin danh mục + Danh sách sản phẩm liên quan (Checklist XLSX 0.25)
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var category = await database.Categories
                .Include(c => c.Products)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (category == null) return NotFound();

            return View(category);
        }

        // GET: Category/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Category/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Category category)
        {
            if (ModelState.IsValid)
            {
                var exists = await database.Categories.AnyAsync(c => c.IDCate == category.IDCate);
                if (exists)
                {
                    ModelState.AddModelError("IDCate", "Mã danh mục này đã tồn tại!");
                    return View(category);
                }

                database.Categories.Add(category);
                await database.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(category);
        }

        // GET: Category/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var category = await database.Categories.FindAsync(id);
            if (category == null) return NotFound();

            return View(category);
        }

        // POST: Category/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Category category)
        {
            if (id != category.Id) return NotFound();

            if (ModelState.IsValid)
            {
                var existing = await database.Categories
                    .Include(c => c.Products)
                    .FirstOrDefaultAsync(c => c.Id == id);
                if (existing == null) return NotFound();

                if (existing.IDCate != category.IDCate)
                {
                    var duplicate = await database.Categories.AnyAsync(c => c.IDCate == category.IDCate && c.Id != id);
                    if (duplicate)
                    {
                        ModelState.AddModelError("IDCate", "Mã danh mục này đã tồn tại!");
                        return View(category);
                    }
                    if (existing.Products != null && existing.Products.Any())
                    {
                        ModelState.AddModelError("IDCate", "Không thể đổi mã danh mục khi đã có sản phẩm liên kết!");
                        return View(category);
                    }
                    existing.IDCate = category.IDCate;
                }

                existing.NameCate = category.NameCate;
                await database.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(category);
        }

        // GET: Category/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var category = await database.Categories
                .Include(c => c.Products)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (category == null) return NotFound();

            return View(category);
        }

        // POST: Category/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var category = await database.Categories
                .Include(c => c.Products)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (category != null)
            {
                // Kiểm tra ràng buộc dữ liệu: Nếu còn sản phẩm thuộc danh mục thì không cho xóa
                if (category.Products != null && category.Products.Any())
                {
                    return Content("Không thể xóa danh mục này vì vẫn còn sản phẩm thuộc danh mục!");
                }

                database.Categories.Remove(category);
                await database.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        // Partial View danh mục
        public IActionResult CategoryPartial()
        {
            var categories = database.Categories.ToList();
            return PartialView(categories);
        }
    }
}
