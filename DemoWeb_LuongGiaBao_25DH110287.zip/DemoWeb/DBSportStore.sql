﻿-- ============================================================
-- T-SQL SCRIPT CHO MICROSOFT SQL SERVER (SSMS)
-- Server: DESKTOP-8SMUIKJ\SQLEXPRESS03 | Database: DBSportStore
-- ============================================================
IF DB_ID(N'DBSportStore') IS NULL
BEGIN
    CREATE DATABASE [DBSportStore];
END
GO

USE [DBSportStore];
GO

IF OBJECT_ID(N'dbo.OrderDetail', N'U') IS NOT NULL DROP TABLE dbo.OrderDetail;
IF OBJECT_ID(N'dbo.OrderPro', N'U')    IS NOT NULL DROP TABLE dbo.OrderPro;
IF OBJECT_ID(N'dbo.Customer', N'U')    IS NOT NULL DROP TABLE dbo.Customer;
IF OBJECT_ID(N'dbo.Product', N'U')     IS NOT NULL DROP TABLE dbo.Product;
IF OBJECT_ID(N'dbo.Category', N'U')    IS NOT NULL DROP TABLE dbo.Category;
IF OBJECT_ID(N'dbo.AdminUser', N'U')   IS NOT NULL DROP TABLE dbo.AdminUser;
GO

-- ============================================================
-- BẢNG 1: AdminUser - Quản lý tài khoản đăng nhập hệ thống
-- ============================================================
CREATE TABLE dbo.AdminUser (
    ID           INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    NameUser     NVARCHAR(50)      NOT NULL,
    RoleUser     NVARCHAR(50)      NULL,
    PasswordUser NVARCHAR(100)     NOT NULL
);
GO

-- ============================================================
-- BẢNG 2: Category - Danh mục thể loại sản phẩm
-- ============================================================
CREATE TABLE dbo.Category (
    Id       INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    IDCate   NVARCHAR(50)      NOT NULL UNIQUE,
    NameCate NVARCHAR(100)     NOT NULL
);
GO

-- ============================================================
-- BẢNG 3: Product - Danh sách sản phẩm
-- ============================================================
CREATE TABLE dbo.Product (
    ProductID     INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    NamePro       NVARCHAR(200)     NOT NULL,
    DecriptionPro NVARCHAR(1000)    NULL,
    Category      NVARCHAR(50)      NULL,
    Price         DECIMAL(18,2)     NULL,
    Image_Pro     NVARCHAR(500)     NULL,
    Quantity      INT               NULL,
    CONSTRAINT FK_Product_Category FOREIGN KEY (Category) REFERENCES dbo.Category (IDCate) ON DELETE SET NULL
);
GO

-- ============================================================
-- BẢNG 4: Customer - Thông tin khách hàng đặt hàng
-- ============================================================
CREATE TABLE dbo.Customer (
    IDCus    INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    NameCus  NVARCHAR(200)     NOT NULL,
    PhoneCus NVARCHAR(50)      NULL,
    EmailCus NVARCHAR(200)     NULL
);
GO

-- ============================================================
-- BẢNG 5: OrderPro - Hóa đơn đặt hàng
-- ============================================================
CREATE TABLE dbo.OrderPro (
    ID              INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    DateOrder       DATETIME2         NULL,
    IDCus           INT               NULL,
    AddressDelivery NVARCHAR(500)     NULL,
    PaymentStatus   NVARCHAR(100)     NULL,
    PaymentMethod   NVARCHAR(100)     NULL,
    ShippingMethod  NVARCHAR(100)     NULL,
    OrderStatus     NVARCHAR(100)     NULL,
    TotalAmount     DECIMAL(18,2)     NULL,
    CONSTRAINT FK_OrderPro_Customer FOREIGN KEY (IDCus) REFERENCES dbo.Customer (IDCus) ON DELETE SET NULL
);
GO

-- ============================================================
-- BẢNG 6: OrderDetail - Chi tiết từng dòng sản phẩm trong hóa đơn
-- ============================================================
CREATE TABLE dbo.OrderDetail (
    ID        INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    IDProduct INT               NULL,
    IDOrder   INT               NULL,
    Quantity  INT               NULL,
    UnitPrice DECIMAL(18,2)     NULL,
    CONSTRAINT FK_OrderDetail_Product  FOREIGN KEY (IDProduct) REFERENCES dbo.Product (ProductID) ON DELETE CASCADE,
    CONSTRAINT FK_OrderDetail_OrderPro FOREIGN KEY (IDOrder)   REFERENCES dbo.OrderPro (ID)       ON DELETE CASCADE
);
GO

-- ============================================================
-- DỮ LIỆU ĐỒNG BỘ TỰ ĐỘNG
-- ============================================================
SET IDENTITY_INSERT dbo.AdminUser ON;
INSERT INTO dbo.AdminUser (ID, NameUser, RoleUser, PasswordUser) VALUES (1, N'admin', N'Administrator', N'123456');
INSERT INTO dbo.AdminUser (ID, NameUser, RoleUser, PasswordUser) VALUES (2, N'lylyly', N'Manager', N'123456');
INSERT INTO dbo.AdminUser (ID, NameUser, RoleUser, PasswordUser) VALUES (3, N'staff', N'Staff', N'123456');
INSERT INTO dbo.AdminUser (ID, NameUser, RoleUser, PasswordUser) VALUES (4, N'user', N'User', N'123456');
SET IDENTITY_INSERT dbo.AdminUser OFF;
GO

SET IDENTITY_INSERT dbo.Category ON;
INSERT INTO dbo.Category (Id, IDCate, NameCate) VALUES (1, N'SACH', N'Sách & Tài liệu');
INSERT INTO dbo.Category (Id, IDCate, NameCate) VALUES (2, N'WATERSPORTS', N'Watersports');
INSERT INTO dbo.Category (Id, IDCate, NameCate) VALUES (3, N'SOCCER', N'Soccer');
INSERT INTO dbo.Category (Id, IDCate, NameCate) VALUES (4, N'LAPTOP', N'Laptop');
INSERT INTO dbo.Category (Id, IDCate, NameCate) VALUES (5, N'DESKTOP', N'Máy tính để bàn');
INSERT INTO dbo.Category (Id, IDCate, NameCate) VALUES (6, N'PHONE', N'Điện thoại');
INSERT INTO dbo.Category (Id, IDCate, NameCate) VALUES (7, N'ACCESSORIES', N'Phụ kiện');
INSERT INTO dbo.Category (Id, IDCate, NameCate) VALUES (8, N'SPORTCHEES', N'Sport Chees');
SET IDENTITY_INSERT dbo.Category OFF;
GO

SET IDENTITY_INSERT dbo.Product ON;
INSERT INTO dbo.Product (ProductID, NamePro, DecriptionPro, Category, Price, Image_Pro, Quantity) VALUES (1, N'Trò Chơi Của Những Kẻ Hiểu Luật', N'Dan Nicholson - Quản lý tài chính cá nhân', N'SACH', 106548.00, N'/Content/images/sach1.png', 20);
INSERT INTO dbo.Product (ProductID, NamePro, DecriptionPro, Category, Price, Image_Pro, Quantity) VALUES (2, N'Nghệ Thuật Từ Chối – Cách Nói Không Mà Vẫn Có Được Đồng Thuận', N'Damon Zahariades - Kỹ năng giao tiếp và từ chối khéo léo', N'SACH', 55900.00, N'/Content/images/sach2.png', 15);
INSERT INTO dbo.Product (ProductID, NamePro, DecriptionPro, Category, Price, Image_Pro, Quantity) VALUES (3, N'Kinh Doanh Thời Trang - 8 Bước Xây Dựng, Vận Hành Và Phát Triển Shop Quần Áo', N'Trần Viết Hùng - Cẩm nang khởi nghiệp thời trang', N'SACH', 142000.00, N'/Content/images/sach3.png', 10);
INSERT INTO dbo.Product (ProductID, NamePro, DecriptionPro, Category, Price, Image_Pro, Quantity) VALUES (4, N'LÀM GIÀU TỪ SIÊU CỔ PHIẾU – Câu Chuyện Của Gã Du Mục Phố Wall', N'Jesse C. Stine - Bí quyết đầu tư chứng khoán', N'SACH', 399000.00, N'/Content/images/sach4.png', 0);
INSERT INTO dbo.Product (ProductID, NamePro, DecriptionPro, Category, Price, Image_Pro, Quantity) VALUES (5, N'Hãy Chăm Sóc Mẹ (Tái Bản 2019)', N'Shin Kyung-sook - Tiểu thuyết tình cảm gia đình cảm động', N'SACH', 67000.00, N'/Content/images/sach5.png', 25);
INSERT INTO dbo.Product (ProductID, NamePro, DecriptionPro, Category, Price, Image_Pro, Quantity) VALUES (6, N'Cây Cam Ngọt Của Tôi', N'José Mauro de Vasconcelos - Tác phẩm văn học kinh điển', N'SACH', 73800.00, N'/Content/images/sach6.png', 0);
INSERT INTO dbo.Product (ProductID, NamePro, DecriptionPro, Category, Price, Image_Pro, Quantity) VALUES (7, N'Kayak', N'Thuyền kayak cá nhân thể thao dưới nước bền bỉ', N'WATERSPORTS', 275000.00, N'/Content/images/kayak.png', 25);
INSERT INTO dbo.Product (ProductID, NamePro, DecriptionPro, Category, Price, Image_Pro, Quantity) VALUES (8, N'Lifejacket', N'Áo phao cứu sinh an toàn tiêu chuẩn quốc tế', N'WATERSPORTS', 48950.00, N'/Content/images/lifejacket.png', 30);
INSERT INTO dbo.Product (ProductID, NamePro, DecriptionPro, Category, Price, Image_Pro, Quantity) VALUES (9, N'Soccer Ball', N'Bóng đá thi đấu đạt chuẩn FIFA chuyên nghiệp', N'SOCCER', 195000.00, N'/Content/images/soccer.png', 50);
INSERT INTO dbo.Product (ProductID, NamePro, DecriptionPro, Category, Price, Image_Pro, Quantity) VALUES (10, N'Corner Flags', N'Cờ góc sân bóng đá chất lượng cao', N'SOCCER', 34950.00, N'/Content/images/flags.png', 0);
INSERT INTO dbo.Product (ProductID, NamePro, DecriptionPro, Category, Price, Image_Pro, Quantity) VALUES (11, N'Stadium', N'Mô hình sân vận động mini sắc nét', N'SOCCER', 795000.00, N'/Content/images/stadium.png', 4);
INSERT INTO dbo.Product (ProductID, NamePro, DecriptionPro, Category, Price, Image_Pro, Quantity) VALUES (12, N'Thinking Cap', N'Mũ bảo hộ đội đầu phong cách thể thao', N'SPORTCHEES', 160000.00, N'/Content/images/cap.png', 40);
INSERT INTO dbo.Product (ProductID, NamePro, DecriptionPro, Category, Price, Image_Pro, Quantity) VALUES (13, N'Unsteady Chair', N'Ghế thể thao gấp gọn dã ngoại tiện lợi', N'SPORTCHEES', 299500.00, N'/Content/images/chair.png', 18);
INSERT INTO dbo.Product (ProductID, NamePro, DecriptionPro, Category, Price, Image_Pro, Quantity) VALUES (14, N'Human Chess Board', N'Bàn cờ vua thể thao kích thước lớn', N'SPORTCHEES', 750000.00, N'/Content/images/chess.png', 8);
INSERT INTO dbo.Product (ProductID, NamePro, DecriptionPro, Category, Price, Image_Pro, Quantity) VALUES (15, N'Bling-Bling King', N'Quân vua cờ vua mạ vàng bóng bẩy', N'SPORTCHEES', 1200000.00, N'/Content/images/king.png', 3);
INSERT INTO dbo.Product (ProductID, NamePro, DecriptionPro, Category, Price, Image_Pro, Quantity) VALUES (16, N'Laptop Dell XPS', N'Laptop mỏng nhẹ hiệu năng vượt trội', N'LAPTOP', 25000000.00, N'/Content/images/laptop.png', 10);
INSERT INTO dbo.Product (ProductID, NamePro, DecriptionPro, Category, Price, Image_Pro, Quantity) VALUES (17, N'iPhone 15 Pro', N'Điện thoại cao cấp camera sắc nét titan', N'PHONE', 28000000.00, N'/Content/images/phone.png', 12);
SET IDENTITY_INSERT dbo.Product OFF;
GO

SET IDENTITY_INSERT dbo.Customer ON;
INSERT INTO dbo.Customer (IDCus, NameCus, PhoneCus, EmailCus) VALUES (1, N'Bui Thi Thanh Tu', N'0901234567', N'thanhtu@huflit.edu.vn');
INSERT INTO dbo.Customer (IDCus, NameCus, PhoneCus, EmailCus) VALUES (2, N'Nguyễn Văn An', N'0987654321', N'vanan@gmail.com');
INSERT INTO dbo.Customer (IDCus, NameCus, PhoneCus, EmailCus) VALUES (3, N'Trần Thị Hoa', N'0912345678', N'hoatran@yahoo.com');
INSERT INTO dbo.Customer (IDCus, NameCus, PhoneCus, EmailCus) VALUES (4, N'Lương Gia Bảo', N'0902693504', N'gbao11062007@gmail.com');
SET IDENTITY_INSERT dbo.Customer OFF;
GO

SET IDENTITY_INSERT dbo.OrderPro ON;
INSERT INTO dbo.OrderPro (ID, DateOrder, IDCus, AddressDelivery, PaymentStatus, PaymentMethod, ShippingMethod, OrderStatus, TotalAmount) VALUES (1, '2025-05-10 12:00:00', 1, N'ànhfkahfkjhakfjahkfj', N'Chưa thanh toán', N'Chưa thanh toán', N'', N'Chờ thanh toán', 624092.00);
INSERT INTO dbo.OrderPro (ID, DateOrder, IDCus, AddressDelivery, PaymentStatus, PaymentMethod, ShippingMethod, OrderStatus, TotalAmount) VALUES (2, '2025-05-10 12:00:00', 1, N'TP. Hồ Chí Minh', N'Thanh toán tiền mặt', N'Tiền mặt', N'Giao hàng nhanh', N'Đang vận chuyển', 617000.00);
INSERT INTO dbo.OrderPro (ID, DateOrder, IDCus, AddressDelivery, PaymentStatus, PaymentMethod, ShippingMethod, OrderStatus, TotalAmount) VALUES (3, '2025-05-10 12:00:00', 1, N'TP. Hồ Chí Minh', N'Thanh toán tiền mặt', N'Tiền mặt', N'Giao hàng tiết kiệm', N'Đã giao', 226548.00);
INSERT INTO dbo.OrderPro (ID, DateOrder, IDCus, AddressDelivery, PaymentStatus, PaymentMethod, ShippingMethod, OrderStatus, TotalAmount) VALUES (4, '2025-05-10 12:00:00', 1, N'TP. Hồ Chí Minh', N'Thanh toán tiền mặt', N'Tiền mặt', N'Giao hàng nhanh', N'Đang xử lý', 791400.00);
INSERT INTO dbo.OrderPro (ID, DateOrder, IDCus, AddressDelivery, PaymentStatus, PaymentMethod, ShippingMethod, OrderStatus, TotalAmount) VALUES (5, '2025-05-10 12:00:00', 1, N'TP. Hồ Chí Minh', N'Chưa thanh toán', N'Chưa thanh toán', N'', N'Chờ thanh toán', 568192.00);
INSERT INTO dbo.OrderPro (ID, DateOrder, IDCus, AddressDelivery, PaymentStatus, PaymentMethod, ShippingMethod, OrderStatus, TotalAmount) VALUES (6, '2026-11-18 08:06:28', 1, N'abcsyz12321 p10 q10', N'Chưa thanh toán', N'Thanh toán tiền mặt', N'Giao hàng nhanh', N'Đang xử lý', 28000000.00);
SET IDENTITY_INSERT dbo.OrderPro OFF;
GO

SET IDENTITY_INSERT dbo.OrderDetail ON;
INSERT INTO dbo.OrderDetail (ID, IDProduct, IDOrder, Quantity, UnitPrice) VALUES (1, 1, 1, 4, 106548.00);
INSERT INTO dbo.OrderDetail (ID, IDProduct, IDOrder, Quantity, UnitPrice) VALUES (2, 2, 1, 1, 55900.00);
INSERT INTO dbo.OrderDetail (ID, IDProduct, IDOrder, Quantity, UnitPrice) VALUES (3, 3, 1, 1, 142000.00);
INSERT INTO dbo.OrderDetail (ID, IDProduct, IDOrder, Quantity, UnitPrice) VALUES (4, 4, 2, 1, 399000.00);
INSERT INTO dbo.OrderDetail (ID, IDProduct, IDOrder, Quantity, UnitPrice) VALUES (5, 5, 2, 3, 67000.00);
INSERT INTO dbo.OrderDetail (ID, IDProduct, IDOrder, Quantity, UnitPrice) VALUES (6, 6, 3, 2, 73800.00);
INSERT INTO dbo.OrderDetail (ID, IDProduct, IDOrder, Quantity, UnitPrice) VALUES (7, 2, 3, 1, 55900.00);
INSERT INTO dbo.OrderDetail (ID, IDProduct, IDOrder, Quantity, UnitPrice) VALUES (8, 7, 4, 2, 275000.00);
INSERT INTO dbo.OrderDetail (ID, IDProduct, IDOrder, Quantity, UnitPrice) VALUES (9, 9, 4, 1, 195000.00);
INSERT INTO dbo.OrderDetail (ID, IDProduct, IDOrder, Quantity, UnitPrice) VALUES (10, 1, 5, 4, 106548.00);
INSERT INTO dbo.OrderDetail (ID, IDProduct, IDOrder, Quantity, UnitPrice) VALUES (11, 3, 5, 1, 142000.00);
INSERT INTO dbo.OrderDetail (ID, IDProduct, IDOrder, Quantity, UnitPrice) VALUES (12, 17, 6, 1, 28000000.00);
SET IDENTITY_INSERT dbo.OrderDetail OFF;
GO
