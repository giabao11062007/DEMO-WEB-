using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DemoWeb.Data;

namespace DemoWeb.ViewComponents
{
    public class CategorySidebarViewComponent : ViewComponent
    {
        private readonly DBSportStoreEntities _db;

        public CategorySidebarViewComponent(DBSportStoreEntities db)
        {
            _db = db;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            var categories = await _db.Categories.ToListAsync();
            return View(categories);
        }
    }
}
